import React from 'react';

function About() {
  return (
    <div>About Us</div>
  );
}

export default About; 



