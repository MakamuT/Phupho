
function Footer() {
    return (
      <footer>
        <p>&copy; 2023 Phupho</p>
      </footer>
    );
  }
  
  export default Footer;