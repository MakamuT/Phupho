import React from 'react';

function Signup() {
  return (
    <div>Signup</div>
  );
}

export default Signup;