import React from 'react';

function Testimonial() {
  return (
    <div>Testimonial</div>
  );
}

export default Testimonial;